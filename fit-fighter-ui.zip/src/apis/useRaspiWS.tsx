// src/apis/RaspiComboWSContext.tsx
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type Phase = "idle" | "show" | "hit";

export type RaspiMsg =
  | { type: "hb"; ts?: number }
  | { type: "game_start"; mode: 1; user: number; duration: number; ts?: number }
  | {
      type: "combo";
      level: "Beginner" | "Intermediate" | "Advanced" | "Expert";
      payload: number[];
      interval?: number;
      showTime?: number;
      ts?: number;
    }
  | { type: "phase"; state: Phase; ts?: number }
  | { type: "press"; pad: number; ts?: number }
  | {
      type: "judge";
      pad: number;
      idx: number;
      correct: boolean;
      reset?: boolean;
      ts?: number;
    }
  | {
      type: "game_end";
      mode: 1;
      user: number;
      score: number;
      misses: number;
      combos_cleared: number;
      avg_combo_time?: number | null;
      elapsed: number;
      ts?: number;
    }
  | { type: "error"; message: string };

type RaspiWSState = {
  connected: boolean;
  phase: Phase;
  currentCombo: number[] | null;
  currentIndex: number; // 0-based expected index during hit phase
  lastPress?: { pad: number; ts?: number; ok: boolean };
  level?: "Beginner" | "Intermediate" | "Advanced" | "Expert";
  // raw socket if you need to send from web later
  socket?: WebSocket | null;
};

const RaspiWSContext = createContext<RaspiWSState>({
  connected: false,
  phase: "idle",
  currentCombo: null,
  currentIndex: 0,
  socket: null,
});

const WS_URL =
  (import.meta.env.VITE_RASPI_WS_URL as string) ||
  // fallback (adjust if needed)
  `ws://${window.location.hostname}:8765`;

export const RaspiWSProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [connected, setConnected] = useState(false);
  const [phase, setPhase] = useState<Phase>("idle");
  const [currentCombo, setCurrentCombo] = useState<number[] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [level, setLevel] = useState<
    "Beginner" | "Intermediate" | "Advanced" | "Expert" | undefined
  >(undefined);
  const [lastPress, setLastPress] =
    useState<RaspiWSState["lastPress"]>(undefined);

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<number | null>(null);

  useEffect(() => {
    let stopped = false;

    const connect = () => {
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = () => {
        if (stopped) return;
        setConnected(true);
      };

      ws.onmessage = (evt) => {
        if (stopped) return;
        let msg: RaspiMsg | null = null;
        try {
          msg = JSON.parse(evt.data);
        } catch {
          return;
        }
        if (!msg) return;

        switch (msg.type) {
          case "combo":
            setLevel(msg.level);
            setCurrentCombo(msg.payload);
            setCurrentIndex(0);
            break;
          case "phase":
            setPhase(msg.state);
            if (msg.state === "show") setCurrentIndex(0);
            break;
          case "press":
            // just mirror presses for UI feedback
            setLastPress({ pad: msg.pad, ts: msg.ts, ok: false });
            break;
          case "judge":
            setLastPress({ pad: msg.pad, ts: msg.ts, ok: msg.correct });
            if (msg.correct) {
              setCurrentIndex(msg.idx); // server sends idx as 1-based progress; if you want 0-based use (msg.idx)
            } else if (msg.reset) {
              setCurrentIndex(0);
            }
            break;
          case "game_start":
            setPhase("show");
            setCurrentIndex(0);
            break;
          case "game_end":
            setPhase("idle");
            setCurrentCombo(null);
            setCurrentIndex(0);
            break;
        }
      };

      ws.onclose = () => {
        if (stopped) return;
        setConnected(false);
        setPhase("idle");
        setCurrentCombo(null);
        setCurrentIndex(0);
        // attempt reconnect
        reconnectRef.current = window.setTimeout(connect, 1000);
      };

      ws.onerror = () => {
        try {
          ws.close();
        } catch {}
      };
    };

    connect();
    return () => {
      stopped = true;
      if (reconnectRef.current) window.clearTimeout(reconnectRef.current);
      try {
        wsRef.current?.close();
      } catch {}
    };
  }, []);

  const value = useMemo<RaspiWSState>(
    () => ({
      connected,
      phase,
      currentCombo,
      currentIndex,
      lastPress,
      level,
      socket: wsRef.current,
    }),
    [connected, phase, currentCombo, currentIndex, lastPress, level]
  );

  return (
    <RaspiWSContext.Provider value={value}>{children}</RaspiWSContext.Provider>
  );
};

// ✅ NAMED HOOK EXPORT
export function useRaspiWS() {
  return useContext(RaspiWSContext);
}
