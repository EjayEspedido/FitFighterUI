export default function PlayRhythm() {
  return (
    <div className="page">
      <h1>Rhythm Mode</h1>
    </div>
  );
}
