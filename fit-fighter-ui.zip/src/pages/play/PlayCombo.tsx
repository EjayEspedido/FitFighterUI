// src/pages/play/PlayCombo.tsx
import React, { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import PadVisualizerComboLive from "../../components/PadVisualizerComboLive";
import EndScreen from "../../components/EndScreen";
import StartScreen from "../../components/StartScreenCombo";
import { useHeartRate } from "../../apis/HeartRateProvider";
import { useRaspiWS } from "../../apis/RaspiComboWSContext";

const PREP_SECONDS = 3; // short "Get Ready" just for UX

const container: React.CSSProperties = {
  minHeight: "100vh",
  background: "#030712",
  color: "#e5e7eb",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  padding: 24,
  gap: 18,
};

const card: React.CSSProperties = {
  width: "100%",
  maxWidth: 920,
  border: "1px solid #1f2937",
  borderRadius: 16,
  padding: 20,
  background:
    "linear-gradient(180deg, rgba(17,24,39,0.8) 0%, rgba(2,6,23,0.9) 100%)",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  gap: 18,
};

const Stat: React.FC<{ label: string; value: number | string }> = ({
  label,
  value,
}) => (
  <div
    style={{
      background: "#0b1220",
      border: "1px solid #1f2937",
      borderRadius: 12,
      padding: 12,
      lineHeight: 1.1,
    }}
  >
    <div style={{ fontSize: 12, opacity: 0.7 }}>{label}</div>
    <div style={{ fontWeight: 900, fontSize: 24 }}>{value}</div>
  </div>
);

export default function PlayCombo() {
  const nav = useNavigate();
  const { bpm } = useHeartRate(); // from TopBarHR/HeartRateProvider
  const {
    connected,
    phase,
    level,
    combo,
    nextIndex,
    duration,
    startedAt,
    ended,
    results,
  } = useRaspiWS();

  const timeLeft = useMemo(() => {
    if (!duration || !startedAt) return "—";
    const ms = Math.max(0, duration * 1000 - (Date.now() - startedAt));
    const s = Math.ceil(ms / 1000);
    const mm = Math.floor(s / 60)
      .toString()
      .padStart(2, "0");
    const ss = (s % 60).toString().padStart(2, "0");
    return `${mm}:${ss}`;
  }, [duration, startedAt]);

  // End screen
  if (ended && results) {
    return (
      <EndScreen
        score={results.score}
        misses={results.misses}
        maxCombo={combo.length} // you can track max across run if desired
        avgHR={null}
        maxHR={null}
        onRestart={() => nav("/")}
      />
    );
  }

  const showPrep = phase === "idle";

  return (
    <div style={container}>
      {/* Header strip */}
      <div
        style={{
          width: "100%",
          maxWidth: 920,
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr",
          gap: 12,
          alignItems: "center",
        }}
      >
        <div style={{ opacity: 0.85 }}>
          <div style={{ fontSize: 12, opacity: 0.7 }}>Level</div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>{level ?? "—"}</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 12, opacity: 0.7 }}>Current Heart Rate</div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>{bpm ?? "—"} bpm</div>
        </div>
        <div style={{ textAlign: "right", opacity: 0.85 }}>
          <div style={{ fontSize: 12, opacity: 0.7 }}>
            {connected ? "Raspi" : "Raspi (offline)"}
          </div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>
            {connected ? "Connected" : "Disconnected"}
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 12,
          width: "100%",
          maxWidth: 920,
        }}
      >
        <Stat label="Duration" value={timeLeft} />
        <Stat label="Combo length" value={combo.length || "—"} />
        <Stat
          label="Progress"
          value={`${Math.min(nextIndex, combo.length)} / ${
            combo.length || "—"
          }`}
        />
      </div>

      {/* Main card */}
      <div style={card}>
        {showPrep && (
          <StartScreen
            duration={PREP_SECONDS}
            onStart={() => {
              /* the Pi will send game_start when it actually begins; we just show a short prep */
            }}
            onExit={() => nav("/")}
            level={level ?? "Intermediate"}
            heartRate={bpm ?? null}
          />
        )}

        {!showPrep && (
          <>
            <h2
              style={{
                margin: 0,
                color: phase === "show" ? "#60a5fa" : "#22c55e",
              }}
            >
              {phase === "show"
                ? "Show Phase"
                : phase === "hit"
                ? "Hit Phase"
                : "Ready"}
            </h2>

            <PadVisualizerComboLive />

            <p style={{ opacity: 0.7, marginTop: 6 }}>
              {phase === "show"
                ? "Watch the combo on the rig. Memorize the order."
                : phase === "hit"
                ? level === "Intermediate"
                  ? "Hit the pads in order. The next pad is hinted in blue."
                  : "Hit the pads in order (no hints)."
                : "Waiting for the session to start..."}
            </p>
          </>
        )}
      </div>

      {/* Exit button under the box */}
      <button
        onClick={() => nav("/")}
        style={{
          marginTop: 8,
          padding: "10px 16px",
          background: "transparent",
          color: "#e5e7eb",
          border: "1px solid #374151",
          borderRadius: 10,
          fontWeight: 700,
          cursor: "pointer",
        }}
      >
        Exit
      </button>
    </div>
  );
}
