export default function PlayFoF() {
  return (
    <div className="page">
      <h1>Friend of Foe Mode</h1>
    </div>
  );
}
