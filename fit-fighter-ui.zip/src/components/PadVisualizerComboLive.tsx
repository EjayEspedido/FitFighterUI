// src/components/PadVisualizerComboLive.tsx
import React, { useMemo } from "react";
import { useRaspiWS } from "../apis/RaspiComboWSContext";

type Props = {
  // How long to keep a press/judge flash visible (ms)
  flashMs?: number;
};

const PAD_IDS = [1, 2, 3, 4, 5, 6, 7, 8];

const bg = {
  panel: "#0b1220",
  border: "#1f2937",
  padIdle: "#0a0f1a",
  padShow: "#2563eb", // blue during Show phase (Intermediate only)
  padNext: "#60a5fa", // hint for next expected pad (Intermediate only)
  padHitGood: "#22c55e",
  padHitBad: "#ef4444",
};

export default function PadVisualizerComboLive({ flashMs = 220 }: Props) {
  const { phase, level, combo, nextIndex, lastPress, lastJudge } = useRaspiWS();

  // compute recent flash state
  const now = Date.now();
  const pressPad =
    lastPress && now - lastPress.at < flashMs ? lastPress.pad : undefined;
  const judge =
    lastJudge && now - lastJudge.at < flashMs ? lastJudge : undefined;

  const expectedPad = combo[nextIndex]; // undefined if done or no combo

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 12,
        width: "100%",
        maxWidth: 920,
      }}
    >
      {PAD_IDS.map((pid) => {
        const isShowPhase = phase === "show";
        const isHitPhase = phase === "hit";

        // visual rules:
        // Intermediate: during SHOW render the sequence one by one? (The Pi drives the LEDs,
        // here we show a generic blue banner to indicate "memorize"; optionally show the correct "next" hint during HIT.)
        // Advanced/Expert: no hints; only flash correct/incorrect.
        let padColor = bg.padIdle;
        let borderColor = bg.border;

        // Flash judge if present
        if (judge && judge.pad === pid) {
          padColor = judge.correct ? bg.padHitGood : bg.padHitBad;
        } else if (pressPad === pid) {
          // transient press highlight (very subtle)
          borderColor = "#475569";
        } else if (isHitPhase) {
          if (level === "Intermediate" && expectedPad === pid) {
            padColor = bg.padNext;
          }
        } else if (isShowPhase) {
          if (level === "Intermediate") {
            // During show, paint nothing specific per-step (the Pi does LEDs),
            // but we can still tint all pads to "blue" to communicate SHOW state.
            padColor = bg.padShow;
          }
        }

        return (
          <div
            key={pid}
            style={{
              height: 84,
              borderRadius: 12,
              background: padColor,
              border: `1px solid ${borderColor}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 800,
              fontSize: 24,
              color: "#e5e7eb",
              boxShadow:
                judge && judge.pad === pid
                  ? `0 0 0 2px ${borderColor}, 0 0 18px ${padColor}`
                  : undefined,
              transition:
                "background 120ms linear, box-shadow 120ms linear, border-color 120ms linear",
            }}
          >
            {pid}
          </div>
        );
      })}
    </div>
  );
}
